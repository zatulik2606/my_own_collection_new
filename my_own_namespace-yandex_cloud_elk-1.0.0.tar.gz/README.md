# Ansible Collection - my_own_namespace.yandex_cloud_elk

This is test homework work Netology

Author: Evgeny Zatulivetrov
